package main;

import controller.Controller;

public class Main {

	public Main() {
		 new Controller();
	}

	public static void main(String[] args) {
		new Main();
	}

}
