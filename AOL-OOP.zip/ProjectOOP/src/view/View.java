package view;

import java.util.Scanner;
import controller.Controller;
import functions.LaperAhWordArt;

public class View {
	
	private Controller remote;
	Scanner scan = new Scanner(System.in);

	public View(Controller remote) {
		this.remote = remote;
	}
	
	public void enter() {
		System.out.println("Press ENTER to continue!");
		scan.nextLine();
	}
	
	public void msg(String msg) {
		LaperAhWordArt.print();
		System.out.println(msg);
		enter();
	}
	
	public void displayLoginMenu() {
		String id;
		LaperAhWordArt.print();
		System.out.print("Enter employee id: ");
		id = scan.nextLine();
		remote.login(id);
	}
	
	public void displayMainMenu() {
		LaperAhWordArt.print();
		System.out.println("1. Login");
		System.out.println("2. Register");
		System.out.println("3. Exit");
		System.out.print("> ");
		String inp = scan.nextLine();
		remote.handleUser(inp);
	}
	
	public void displayRegisMenu() {
		String name, location;
		LaperAhWordArt.print();
		System.out.print("Enter your name: ");
		name = scan.nextLine();
		System.out.print("Enter your location: ");
		location = scan.nextLine();
		remote.regis(name, location);
	}
	
	public void displayInAppMenu(String location) {
		LaperAhWordArt.print();
		System.out.println("Your location: " + location);
		System.out.println("1. Add new reservation");
		System.out.println("2. See all reservation");
		System.out.println("3. Manage reservation");
		System.out.println("4. Add new menu");
		System.out.println("5. See all menu");
		System.out.println("6. Manage menu (Alter | Delete)");
		System.out.println("7. Log Out");
		System.out.print("> ");
		String inp = scan.nextLine();
		remote.handleInApp(inp, location);
	}
	
	public void displayAddReservation(String location) {
		String name, tableType;
		int tableAmmount, peoplePerTable;
		
		LaperAhWordArt.print();
		System.out.println("Your location: " + location);
		System.out.print("Enter customer name: ");
		name = scan.nextLine();
		System.out.print("Enter Table Ammount: ");
		tableAmmount = Integer.parseInt(scan.nextLine());
		System.out.print("Table Type [Romantic | General | Family]: ");
		tableType = scan.nextLine();
		System.out.print("People per Table: ");
		peoplePerTable = Integer.parseInt(scan.nextLine());
		remote.addReservation(name, location, tableAmmount, tableType, peoplePerTable, "in reserve");
	}
	
	public boolean yesOrNo(String msg) {
		String input;
		System.out.print(msg + " ");
		input = scan.nextLine();
		if(input.equalsIgnoreCase("Yes")) return true;
		else if (input.equalsIgnoreCase("No")) return false;
		else return yesOrNo(msg);
	}
	
	public void displayAddMenu(String location) {
		LaperAhWordArt.print();
		System.out.println("Your location: " + location);
		String menuName;
		int menuPrice;
		
		if(location.contentEquals("Bandung") || location.contentEquals("Jakarta") || location.contentEquals("Bali")) {
			if(yesOrNo("Special Menu [ 'Yes' | 'No' ]: ")) {
				String story;
				System.out.print("Enter menu name: ");
				menuName = scan.nextLine();
				System.out.print("Enter menu price: ");
				menuPrice = Integer.parseInt(scan.nextLine());
				System.out.print("Enter menu's story: ");
				story = scan.nextLine();
				remote.addMenu(menuName, menuPrice, location, story);
			}
			else {
				System.out.print("Enter menu name: ");
				menuName = scan.nextLine();
				System.out.print("Enter menu price: ");
				menuPrice = Integer.parseInt(scan.nextLine());
				remote.addMenu(menuName, menuPrice, location);
			}
		}
		else if(location.contentEquals("Surabaya") || location.contentEquals("Samarinda") || location.contentEquals("Padang")) {
			if(yesOrNo("Local Special Menu [ 'Yes' | 'No' ]: ")) {
				String uniqueness, localLocation;
				System.out.print("Enter menu name: ");
				menuName = scan.nextLine();
				System.out.print("Enter menu price: ");
				menuPrice = Integer.parseInt(scan.nextLine());
				System.out.print("Enter uniqueness: ");
				uniqueness = scan.nextLine();
				System.out.println("Enter Local Location: ");
				localLocation = scan.nextLine();
				remote.addMenu(menuName, menuPrice, location, uniqueness, localLocation);
			}
			else {
				System.out.print("Enter menu name: ");
				menuName = scan.nextLine();
				System.out.print("Enter menu price: ");
				menuPrice = Integer.parseInt(scan.nextLine());
				remote.addMenu(menuName, menuPrice, location);
			}
		}
		else {
			System.out.print("Enter menu name: ");
			menuName = scan.nextLine();
			System.out.print("Enter menu price: ");
			menuPrice = Integer.parseInt(scan.nextLine());
			remote.addMenu(menuName, menuPrice, location);
		}
	}
	
	public String pickAReservation() {
		String id;
		System.out.print("Enter reservation id: ");
		id = scan.nextLine();
		return id;
	}
	
	public void displayReservationManagement(String id, String location) {
		System.out.println("1. The reserve have arrive (in reserve -> in order)");
		System.out.println("2. Checkout (in order -> finalized, show the bill)");
		System.out.println("3. Order (Make an order)");
		System.out.println("4. Exit");
		System.out.print("> ");
		String inp = scan.nextLine();
		if(inp.equals("1")) remote.reserveArrive(id, location);
		else if(inp.equals("2")) remote.checkOut(id, location);
		else if(inp.equals("3")) remote.addOrder(id, location);
		else if(inp.equals("4")) return;
		else {
			msg("Invalid Input!");
			displayReservationManagement(id, location);
		}
	}
	
	public String pickAMenu() {
		String id;
		System.out.print("Enter menu id: ");
		id = scan.nextLine();
		return id;
	}
	
	public void manageMenu(String id, String location) {
		if(yesOrNo("Delete this menu [ 'Yes' | 'No' ]: ")) {
			remote.deleteMenu(id, location);
		}
		else {
			String name;
			int price;
			System.out.print("Enter new name: ");
			name = scan.nextLine();
			System.out.print("Enter new price: ");
			price = Integer.parseInt(scan.nextLine());
			remote.updateMenu(id, name, price, location);
		}
	}
}
