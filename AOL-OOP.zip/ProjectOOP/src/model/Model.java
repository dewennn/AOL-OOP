package model;
import java.sql.*;
import java.util.Scanner;

import controller.Controller;

public class Model {
	
	private Connection conn;
	private Statement query;
	Scanner scan = new Scanner(System.in);

	public Model(Controller remote) {
		try {
			conn = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/LaperAh","root","");
			query = conn.createStatement();
		} catch (SQLException e) {
			System.out.println("Connection Fail!");
		}
	}
	
	public boolean regisUser(String id, String name, String location) {
		boolean userRegistered = false;
	    
	    try {
	        String sql = "INSERT INTO MsEmployee VALUES (?, ?, ?)";
	        try (PreparedStatement preparedStatement = conn.prepareStatement(sql)) {
	            preparedStatement.setString(1, id);
	            preparedStatement.setString(2, name);
	            preparedStatement.setString(3, location);

	            int rowsAffected = preparedStatement.executeUpdate();
	            userRegistered = rowsAffected > 0;
	        }
	    } catch (SQLException e) {
	        System.out.println("Register User Fail!");
	    }

	    return userRegistered;
	}
	
	public boolean addReservation(String id, String name, String location, int tableAmmount, String tableType, int peoplePerTable, String status) {
		boolean userRegistered = false;
	    
	    try {
	        String sql = "INSERT INTO MsReservation VALUES (?, ?, ?, ?, ?, ?, ?)";
	        try (PreparedStatement preparedStatement = conn.prepareStatement(sql)) {
	            preparedStatement.setString(1, id);
	            preparedStatement.setString(2, name);
	            preparedStatement.setString(3, location);
	            preparedStatement.setInt(4, tableAmmount);
	            preparedStatement.setString(5, tableType);
	            preparedStatement.setInt(6, peoplePerTable);
	            preparedStatement.setString(7, status);

	            int rowsAffected = preparedStatement.executeUpdate();
	            userRegistered = rowsAffected > 0;
	        }
	    } catch (SQLException e) {
	        System.out.println("Add Reservation Fail!");
	    }

	    return userRegistered;
	}
	
	public boolean addMenu(String id, String name, Integer price, String location) {
		boolean menuAdded = false;
	    
	    try {
	        String sql = "INSERT INTO MsMenu VALUES (?, ?, ?, ?, ?, ?)";
	        try (PreparedStatement preparedStatement = conn.prepareStatement(sql)) {
	            preparedStatement.setString(1, id);
	            preparedStatement.setString(2, name);
	            preparedStatement.setInt(3, price);
	            preparedStatement.setString(4, location);
	            preparedStatement.setString(5, null);
	            preparedStatement.setString(6, null);

	            int rowsAffected = preparedStatement.executeUpdate();
	            menuAdded = rowsAffected > 0;
	        }
	    } catch (SQLException e) {
	        System.out.println("Menu Add Fail!");
	    }

	    return menuAdded;
	}
	
	public boolean addSpecialMenu(String id, String name, Integer price, String location, String specialId, String story) {
		boolean menuAdded = false;
		
		try {
	        String sql = "INSERT INTO MsSpecialMenu VALUES (?, ?)";
	        try (PreparedStatement preparedStatement = conn.prepareStatement(sql)) {
	            preparedStatement.setString(1, specialId);
	            preparedStatement.setString(2, story);

	            int rowsAffected = preparedStatement.executeUpdate();
	            menuAdded = rowsAffected > 0;
	        }
	    } catch (SQLException e) {
	        System.out.println("Special Menu Add Fail!");
	    }
	    
	    try {
	        String sql = "INSERT INTO MsMenu VALUES (?, ?, ?, ?, ?, ?)";
	        try (PreparedStatement preparedStatement = conn.prepareStatement(sql)) {
	            preparedStatement.setString(1, id);
	            preparedStatement.setString(2, name);
	            preparedStatement.setInt(3, price);
	            preparedStatement.setString(4, location);
	            preparedStatement.setString(5, specialId);
	            preparedStatement.setString(6, null);

	            int rowsAffected = preparedStatement.executeUpdate();
	            menuAdded = rowsAffected > 0;
	        }
	    } catch (SQLException e) {
	        System.out.println("Menu Add Fail!");
	    }

	    return menuAdded;
	}
	
	public boolean addLocalSpecialMenu(String id, String name, Integer price, String location, String localSpecialId, String uniqueness, String localLocation) {
		boolean menuAdded = false;
		
		try {
	        String sql = "INSERT INTO MsLocalSpecialMenu VALUES (?, ?, ?)";
	        try (PreparedStatement preparedStatement = conn.prepareStatement(sql)) {
	            preparedStatement.setString(1, localSpecialId);
	            preparedStatement.setString(2, uniqueness);
	            preparedStatement.setString(3, localLocation);

	            int rowsAffected = preparedStatement.executeUpdate();
	            menuAdded = rowsAffected > 0;
	        }
	    } catch (SQLException e) {
	        System.out.println("Local Special Menu Add Fail!");
	    }
	    
	    try {
	        String sql = "INSERT INTO MsMenu VALUES (?, ?, ?, ?, ?, ?)";
	        try (PreparedStatement preparedStatement = conn.prepareStatement(sql)) {
	            preparedStatement.setString(1, id);
	            preparedStatement.setString(2, name);
	            preparedStatement.setInt(3, price);
	            preparedStatement.setString(4, location);
	            preparedStatement.setString(5, null);
	            preparedStatement.setString(6, localSpecialId);

	            int rowsAffected = preparedStatement.executeUpdate();
	            menuAdded = rowsAffected > 0;
	        }
	    } catch (SQLException e) {
	        System.out.println("Menu Add Fail!");
	    }

	    return menuAdded;
	}
	
	public String userExist(String id) {
		ResultSet rs = null;
		try {
			rs = query.executeQuery("SELECT * FROM MsEmployee WHERE EmployeeId = '" + id + "';");
		} catch (SQLException e) {
			System.out.println("Find user fail!");
		}
		String location = null;
		
		try {
			while(rs.next()) {
				if(rs.getString("EmployeeID").equals(id)) location = rs.getString("EmployeeLocation");
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		return location;
	}
	
	public boolean reservationExist(String id) {
		ResultSet rs = null;
		try {
			rs = query.executeQuery("SELECT * FROM MsReservation WHERE ReservationID = '" + id + "';");
		} catch (SQLException e) {
			System.out.println("Find reservation fail!");
		}
		
		try {
			while(rs.next()) {
				if(rs.getString("ReservationID").equals(id)) return true;
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		return false;
	}
	
	public void showAllReservation(String location) {
		ResultSet rs = null;
		try {
			rs = query.executeQuery("SELECT * FROM MsReservation WHERE Reservationlocation = '" + location + "';");
		} catch (SQLException e) {
			System.out.println("Show Reservation fail!");
		}
		
		System.out.println("=========================================================================================================");
		System.out.println("| No. | Reservation ID | Customer Name | Table Ammount | Table Type | People per Table | Status         |");
		System.out.println("=========================================================================================================");
		try {
			int ctr = 1;
			while(rs.next()) {
				System.out.printf("| %-4d| %-15s| %-14s| %-14d| %-11s| %-17d| %-15s|\n",
						ctr, rs.getString("ReservationID"), rs.getString("CustomerName"), rs.getInt("TableAmmount"),
						rs.getString("TableType"), rs.getInt("PeoplePerTable"), rs.getString("Status"));
				ctr++;
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		System.out.println("=========================================================================================================");
	}
	
	public String menuExist(String id) {
		ResultSet rs = null;
		String location = null;
		try {
			rs = query.executeQuery("SELECT * FROM MsMenu WHERE MenuID = '" + id + "';");
		} catch (SQLException e) {
			System.out.println("Find menu fail!");
		}
		
		try {
			while(rs.next()) {
				if(rs.getString("MenuID").equals(id)) location = rs.getString("Location");
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		return location;
	}
	
	public void showAllMenu(String location) {
		
		if(location.contentEquals("Bandung") || location.contentEquals("Jakarta") || location.contentEquals("Bali")) {
			ResultSet rs = null;
			try {
				rs = query.executeQuery(
						"SELECT * FROM MsMenu LEFT JOIN MsSpecialMenu ON MsMenu.SpecialID = MsSpecialMenu.SpecialID WHERE MsMenu.Location = '" + location + "';");
			} catch (SQLException e) {
				System.out.println("Show Menu fail!");
				e.printStackTrace();
			}
			
			System.out.println("=================================================================================");
			System.out.println("| No. | Menu ID | Menu Name       | Menu Price | Story                          |");
			System.out.println("=================================================================================");
			try {
				int ctr = 1;
				while(rs.next()) {
					System.out.printf("| %-4d| %-8s| %-16s| %-11d| %-31s|\n",
							ctr, rs.getString("MenuID"), rs.getString("MenuName"), rs.getInt("MenuPrice"), rs.getString("Story"));
					ctr++;
				}
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			System.out.println("=================================================================================");
		}
		else if(location.contentEquals("Surabaya") || location.contentEquals("Samarinda") || location.contentEquals("Padang")) {
			ResultSet rs = null;
			try {
				rs = query.executeQuery(
						"SELECT * FROM MsMenu LEFT JOIN MsLocalSpecialMenu ON MsMenu.LocalSpecialID = MsSpecialMenu.LocalSpecialID WHERE MsMenu.Location = '" + location + "';");
			} catch (SQLException e) {
				System.out.println("Show Menu fail!");
				e.printStackTrace();
			}
			
			System.out.println("==================================================================================================");
			System.out.println("| No. | Menu ID | Menu Name       | Menu Price | Uniqueness                     | Local Location |");
			System.out.println("==================================================================================================");
			try {
				int ctr = 1;
				while(rs.next()) {
					System.out.printf("| %-4d| %-8s| %-16s| %-11d| %-31s| %-13s|\n",
							ctr, rs.getString("MenuID"), rs.getString("MenuName"), rs.getInt("MenuPrice"), rs.getString("Uniqueness"), rs.getString("LocalLocation"));
					ctr++;
				}
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			System.out.println("==================================================================================================");
		}
		else {
			ResultSet rs = null;
			try {
				rs = query.executeQuery(
						"SELECT * FROM MsMenu WHERE MsMenu.Location = '" + location + "';");
			} catch (SQLException e) {
				System.out.println("Show Menu fail!");
				e.printStackTrace();
			}
			
			System.out.println("================================================");
			System.out.println("| No. | Menu ID | Menu Name       | Menu Price |");
			System.out.println("================================================");
			try {
				int ctr = 1;
				while(rs.next()) {
					System.out.printf("| %-4d| %-8s| %-16s| %-11d|\n",
							ctr, rs.getString("MenuID"), rs.getString("MenuName"), rs.getInt("MenuPrice"));
					ctr++;
				}
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			System.out.println("================================================");
		}
		
	}
	
	public boolean specialExist(String id) {
		ResultSet rs = null;
		try {
			rs = query.executeQuery("SELECT * FROM MsSpecialMenu WHERE SpecialID = '" + id + "';");
		} catch (SQLException e) {
			System.out.println("Find special menu fail!");
		}
		
		try {
			while(rs.next()) {
				if(rs.getString("SpecialID").equals(id)) return true;
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		return false;
	}
	
	public boolean localSpecialExist(String id) {
		ResultSet rs = null;
		try {
			rs = query.executeQuery("SELECT * FROM MsLocalSpecialMenu WHERE LocalSpecialID = '" + id + "';");
		} catch (SQLException e) {
			System.out.println("Find local menu fail!");
		}
		
		try {
			while(rs.next()) {
				if(rs.getString("LocalSpecialID").equals(id)) return true;
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		return false;
	}
	
	public boolean menuHaveBeenOrdered(String id) {
		ResultSet rs = null;
		try {
			rs = query.executeQuery("SELECT * FROM MsOrders WHERE MenuID = '" + id + "';");
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Find menu from MsOrders Table fail!");
		}
		
		try {
			if(!rs.next()) {
				rs = query.executeQuery("SELECT * FROM MsPayed WHERE MenuID = '" + id + "';");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			return rs.next();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return false;
	}
	
	public boolean inOrder(String id) {
	    try {
	        query.executeUpdate("UPDATE MsReservation SET Status = 'in order' WHERE ReservationID = '" + id + "';");
	        return true;
	    } catch (SQLException e1) {
	        System.out.println("inOrder status update failed!");
	    }
	    return false;
	}

	public boolean payOrder(String id) {
	    try {
	        // Copy data from MsOrders to MsPayed
	        query.executeUpdate("INSERT INTO MsPayed SELECT * FROM MsOrders WHERE ReservationID = '" + id + "';");
	    } catch (SQLException e) {
	        System.out.println("Insert into payment failed!");
	        return false;
	    }

	    try {
	        // Update status to 'finalized' in MsReservation
	        query.executeUpdate("UPDATE MsReservation SET Status = 'finalized' WHERE ReservationID = '" + id + "';");
	    } catch (SQLException e1) {
	        System.out.println("payOrder status update failed!");
	        return false;
	    }

	    try {
	        // Delete the order from MsOrders
	        query.executeUpdate("DELETE FROM MsOrders WHERE ReservationID = '" + id + "';");
	        return true;
	    } catch (SQLException e) {
	        System.out.println("Order delete failed!");
	        return false;
	    }
	}
	
	public void showBill(String id, String location) {
		
		System.out.println("Reservation: " + id);
		if(location.contentEquals("Bandung") || location.contentEquals("Jakarta") || location.contentEquals("Bali")) {
			ResultSet rs = null;
			try {
				rs = query.executeQuery(
						"SELECT * FROM MsPayed JOIN MsMenu ON MsPayed.MenuID = MsMenu.MenuID JOIN MsSpecialMenu ON MsMenu.SpecialID = MsSpecialMenu.SpecialID WHERE MsPayed.ReservationID = '" + id + "';");
			} catch (SQLException e) {
				System.out.println("Show bill fail!");
				e.printStackTrace();
			}
			
			System.out.println("=================================================================================");
			System.out.println("| No. | Menu ID | Menu Name       | Menu Price | Story                          |");
			System.out.println("=================================================================================");
			try {
				int ctr = 1;
				while(rs.next()) {
					System.out.printf("| %-4d| %-8s| %-16s| %-11d| %-31s|\n",
							ctr, rs.getString("MenuID"), rs.getString("MenuName"), rs.getInt("MenuPrice"), rs.getString("Story"));
					ctr++;
				}
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			System.out.println("=================================================================================");
		}
		else if(location.contentEquals("Surabaya") || location.contentEquals("Samarinda") || location.contentEquals("Padang")) {
			ResultSet rs = null;
			try {
				rs = query.executeQuery(
						"SELECT * FROM MsPayed JOIN MsMenu ON MsPayed.MenuID = MsMenu.MenuID JOIN MsLocalSpecialMenu ON MsMenu.LocalSpecialID = MsSpecialMenu.LocalSpecialID WHERE MsPayed.ReservationID = '" + id + "';");
			} catch (SQLException e) {
				System.out.println("Show bill fail!");
				e.printStackTrace();
			}
			
			System.out.println("==================================================================================================");
			System.out.println("| No. | Menu ID | Menu Name       | Menu Price | Uniqueness                     | Local Location |");
			System.out.println("==================================================================================================");
			try {
				int ctr = 1;
				while(rs.next()) {
					System.out.printf("| %-4d| %-8s| %-16s| %-11d| %-31s| %-13s|\n",
							ctr, rs.getString("MenuID"), rs.getString("MenuName"), rs.getInt("MenuPrice"), rs.getString("Uniqueness"), rs.getString("LocalLocation"));
					ctr++;
				}
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			System.out.println("==================================================================================================");
		}
		else {
			ResultSet rs = null;
			try {
				rs = query.executeQuery(
						"SELECT * FROM MsPayed JOIN MsMenu ON MsPayed.MenuID = MsMenu.MenuID WHERE MsPayed.ReservationID = '" + id + "';");
			} catch (SQLException e) {
				System.out.println("Show bill fail!");
				e.printStackTrace();
			}
			
			System.out.println("================================================");
			System.out.println("| No. | Menu ID | Menu Name       | Menu Price |");
			System.out.println("================================================");
			try {
				int ctr = 1;
				while(rs.next()) {
					System.out.printf("| %-4d| %-8s| %-16s| %-11d|\n",
							ctr, rs.getString("MenuID"), rs.getString("MenuName"), rs.getInt("MenuPrice"));
					ctr++;
				}
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			System.out.println("================================================");
		}
		
	}
	
	public boolean deleteMenu(String id) {
	    try {
	        // Use executeUpdate for DELETE operations
	        int rowsAffected = query.executeUpdate("DELETE FROM MsMenu WHERE MenuID = '" + id + "';");

	        // Check if any rows were affected (deleted)
	        if (rowsAffected > 0) {
	            return true;
	        } else {
	            // Handle the case where no rows were deleted
	            return false;
	        }
	    } catch (SQLException e) {
	        // Handle SQL exceptions
	        e.printStackTrace();
	    }
	    return false;
	}

	
	public boolean updateMenu(String id, String name, int price) {
	    try {
	        // Use executeUpdate for UPDATE operations
	        int rowsAffected = query.executeUpdate("UPDATE MsMenu SET MenuName = '" + name + "', MenuPrice = " + price + " WHERE MenuID = '" + id + "';");

	        // Check if any rows were affected (updated)
	        if (rowsAffected > 0) {
	            return true;
	        } else {
	            // Handle the case where no rows were updated
	            return false;
	        }
	    } catch (SQLException e) {
	        // Handle SQL exceptions
	        e.printStackTrace();
	    }
	    return false;
	}

}
