package functions;

public class LaperAhWordArt {

	public static void print() {
		ClearScreen.print();
		System.out.printf(
				"  _                        _   _    \r\n" + 
				" | |   __ _ _ __  ___ _ _ /_\\ | |_  \r\n" + 
				" | |__/ _` | '_ \\/ -_) '_/ _ \\| ' \\ \r\n" + 
				" |____\\__,_| .__/\\___|_|/_/ \\_\\_||_|\r\n" + 
				"           |_|                      \n"+
				"======================================\n");
	}
}
