package functions;

public class ClearScreen {

	public static void print(){
		for(int i = 0; i < 20; i++) {
			System.out.println();
		}
	}

}
