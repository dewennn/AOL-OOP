package controller;

import java.util.Random;

public class MenuHandler {

	private Controller remote;
	private Random rand = new Random();

	public MenuHandler(Controller remote) {
		this.remote = remote;
	}
	
	private String generateId() {
		String id = "MN";
		for(int i = 0; i < 3; i++) {
			id += rand.nextInt(10);
		}
		return id;
	}
	
	boolean addMenu(String name, Integer price, String location) {
		String id;
		do {
			id = generateId();
		}while(remote.database.menuExist(id) != null);
		return this.remote.database.addMenu(id, name, price, location);
	}
	
	private String generateSpecialId() {
		String id = "SP";
		for(int i = 0; i < 3; i++) {
			id += rand.nextInt(10);
		}
		return id;
	}
	
	boolean addSpecialMenu(String name, Integer price, String location, String story) {
		String id;
		do {
			id = generateId();
		}while(remote.database.menuExist(id) != null);
		String specialId;
		do {
			specialId = generateSpecialId();
		}while(remote.database.specialExist(specialId));
		
		return this.remote.database.addSpecialMenu(id, name, price, location, specialId, story);
	}
	
	private String generateLocalId() {
		String id = "LC";
		for(int i = 0; i < 3; i++) {
			id += rand.nextInt(10);
		}
		return id;
	}
	
	boolean addLocalSpecialMenu(String name, Integer price, String location, String uniqueness, String localLocation) {
		String id;
		do {
			id = generateId();
		}while(remote.database.menuExist(id) != null);
		String localSpecialId;
		do {
			localSpecialId = generateLocalId();
		}while(remote.database.localSpecialExist(localSpecialId));
		
		return this.remote.database.addLocalSpecialMenu(id, name, price, location, localSpecialId, uniqueness, localLocation);
	}
}
