package controller;

import java.util.Random;

public class ReservationHandler {
	
	private Controller remote;
	private Random rand = new Random();

	public ReservationHandler(Controller remote) {
		this.remote = remote;
	}
	
	private String generateId() {
		String id = "RV";
		for(int i = 0; i < 3; i++) {
			id += rand.nextInt(10);
		}
		return id;
	}
	
	boolean addReservation(String name, String location, int tableAmmount, String tableType, int peoplePerTable, String status) {
		String id;
		do {
			id = generateId();
		}while(remote.database.reservationExist(id));
		return this.remote.database.addReservation(id, name, location, tableAmmount, tableType, peoplePerTable, status);
	}

}
