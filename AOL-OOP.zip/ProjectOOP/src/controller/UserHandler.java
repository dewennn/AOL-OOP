package controller;

import java.util.Random;

public class UserHandler {
	
	private Controller remote;
	private Random rand = new Random();

	public UserHandler(Controller remote) {
		this.remote = remote;
	}
	
	private String generateId() {
		String id = "EP";
		for(int i = 0; i < 3; i++) {
			id += rand.nextInt(10);
		}
		return id;
	}
	
	String login(String id) {
		return this.remote.database.userExist(id);
	}
	
	boolean regis(String name, String location) {
		String id;
		do {
			id = generateId();
		}while(remote.database.userExist(id) != null);
		return this.remote.database.regisUser(id, name, location);
	}

}
