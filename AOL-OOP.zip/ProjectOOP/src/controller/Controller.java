package controller;

import functions.LaperAhWordArt;
import model.Model;
import view.View;

public class Controller {
	
	View window;
	Model database;
	UserHandler uh;
	ReservationHandler rh;
	MenuHandler mh;
	
	public Controller() {
		window = new View(this);
		database = new Model(this);
		uh = new UserHandler(this);
		rh = new ReservationHandler(this);
		mh = new MenuHandler(this);
		
		window.displayMainMenu();
	}
	
	public void handleUser(String inp) {
		if(inp.equals("1")) {
			window.displayLoginMenu();
		}
		else if(inp.equals("2")) {
			window.displayRegisMenu();
		}
		else if(inp.equals("3")) {
			return;
		}
		else{
			window.msg("Invalid Input!!");
			window.displayMainMenu();
		}
	}
	
	public void login(String id) {
		String location = uh.login(id);
		if(location != null) {
			window.msg("Login successfull!!");
			window.displayInAppMenu(location);
		}
		else {
			window.msg("User doesn't exist!!");
			window.displayMainMenu();
		}
	}
	
	public void regis(String name, String location) {
		location = location.toLowerCase();
		location = Character.toUpperCase(location.charAt(0)) + location.substring(1);
		
		if(uh.regis(name, location)) {
			window.msg("User Registered Succesfully!!");
			window.displayMainMenu();
		}
		else {
			window.msg("Invalid name / location!!");
			window.displayMainMenu();
		}
	}
	
	public void handleInApp(String inp, String location) {
		if(inp.equals("1")) {
			window.displayAddReservation(location);
		}
		else if(inp.equals("2")) {
			LaperAhWordArt.print();
			System.out.println("Your location: " + location);
			database.showAllReservation(location);
			window.enter();
			window.displayInAppMenu(location);
		}
		else if(inp.equals("3")) {
			LaperAhWordArt.print();
			System.out.println("Your location: " + location);
			database.showAllReservation(location);
			
			String id = window.pickAReservation();
			if(database.reservationExist(id)) {
				window.displayReservationManagement(id, location);
			}
			else {
				window.msg("Reservation don't exist!!");
				window.displayInAppMenu(location);
			}
			
			window.displayReservationManagement(id, location);
		}
		else if(inp.equals("4")) {
			window.displayAddMenu(location);
		}
		else if(inp.equals("5")) {
			LaperAhWordArt.print();
			System.out.println("Your location: " + location);
			database.showAllMenu(location);
			window.enter();
			window.displayInAppMenu(location);
		}
		else if(inp.equals("6")) {
			LaperAhWordArt.print();
			System.out.println("Your location: " + location);
			database.showAllMenu(location);
			String id = window.pickAMenu();
			if(database.menuExist(id) != null && !database.menuHaveBeenOrdered(id)) {		
				window.manageMenu(id, location);
			}
			else {
				window.msg("This menu cannot be changed!!");
				window.displayInAppMenu(location);
			}
		}
		else if(inp.equals("7")) {
			return;
		}
		else{
			window.msg("Invalid Input!!");
			window.displayInAppMenu(location);
		}
	}
	
	public void addReservation(String name, String location, int tableAmmount, String tableType, int peoplePerTable, String status) {
		if(rh.addReservation(name, location, tableAmmount, tableType, peoplePerTable, status)) {
			window.msg("Reservation Success!!");
			window.displayInAppMenu(location);
		}
		else {
			window.msg("Reservation Failed!! Check your inputs");
			window.displayInAppMenu(location);
		}
	}
	
	public void addMenu(String name, Integer price, String location) {
		if(mh.addMenu(name, price, location)) {
			window.msg("Menu Added Successfully!!");
			window.displayInAppMenu(location);
		}
		else {
			window.msg("Menu Addition Failed!! Check your inputs");
			window.displayInAppMenu(location);
		}
	}
	
	public void addMenu(String name, Integer price, String location, String story) {
		if(mh.addSpecialMenu(name, price, location, story)) {
			window.msg("Menu Added Successfully!!");
			window.displayInAppMenu(location);
		}
		else {
			window.msg("Menu Addition Failed!! Check your inputs");
			window.displayInAppMenu(location);
		}
	}
	
	public void addMenu(String name, int price, String location, String uniqueness, String localLocation) {
		if(mh.addLocalSpecialMenu(name, price, location, uniqueness, localLocation)) {
			window.msg("Menu Added Successfully!!");
			window.displayInAppMenu(location);
		}
		else {
			window.msg("Menu Addition Failed!! Check your inputs");
			window.displayInAppMenu(location);
		}
	}
	
	public void deleteMenu(String id, String location) {
		if(database.deleteMenu(id)) {
			window.msg("Menu Deleted Successfully!!");
			window.displayInAppMenu(location);
		}
		else {
			window.msg("Menu Deletion Failed!!");
			window.displayInAppMenu(location);
		}
	}
	
	public void updateMenu(String id, String name, int price, String location) {
		if(database.updateMenu(id, name, price)) {
			window.msg("Menu Updated Successfully!!");
			window.displayInAppMenu(location);
		}
		else {
			window.msg("Menu Update Failed!!");
			window.displayInAppMenu(location);
		}
	}
	
	public void reserveArrive(String id, String location) {
		if(database.inOrder(id)) {
			window.msg("Reservartion " + id + " status have been changed to in order!");
			window.displayReservationManagement(id, location);
		}
		else {
			window.msg("Reservartion " + id + " status change failed!");
			window.displayReservationManagement(id, location);
		}
	}
	
	public void checkOut(String id, String location) {
		if(database.payOrder(id)) {
			
		}
		else {
			
		}
	}
	
	public void addOrder(String id, String location) {
		
	}
}
